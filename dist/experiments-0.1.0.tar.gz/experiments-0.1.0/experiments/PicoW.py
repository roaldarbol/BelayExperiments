
from belay import Device
import time

class PicoW(Device):
    @Device.setup
    def setup():
        led = Pin('LED', Pin.OUT)

    @Device.task
    def led_toggle():
        led.toggle()

if __name__ == "__main__":
    picoW = PicoW('/dev/cu.usbmodem14140')
    picoW.setup()
    picoW.led_toggle()
    time.sleep(2)
    picoW.led_toggle()
    picoW.close()