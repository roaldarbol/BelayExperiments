# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['experiments']

package_data = \
{'': ['*']}

install_requires = \
['belay>=0.15,<0.16']

setup_kwargs = {
    'name': 'experiments',
    'version': '0.1.0',
    'description': '',
    'long_description': '',
    'author': 'Mikkel Roald-Arbøl',
    'author_email': 'github.ggb9a@simplelogin.co',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
